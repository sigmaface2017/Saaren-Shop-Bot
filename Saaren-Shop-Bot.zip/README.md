# Saaren Shop Telegram Bot

## Render Background Worker settings
- Runtime: Python 3
- Build Command: `pip install -r requirements.txt`
- Start Command: `python main.py`

## Environment variables (Render → Environment)
- `BOT_TOKEN`: fresh token from BotFather (never publish it)
- `ADMIN_IDS`: numeric Telegram user ID(s), comma-separated
- `BOT_USERNAME`: `Saaren_Mezon_bot`
- `STORE_CHANNEL`: `@saaren_mezon_hamkari`

The admin must open the bot and press Start once before the bot can DM them.
The channel should contain product posts. For each product, the admin runs `/makebutton 101`
in the bot; the bot returns a deep link. Add that link as the URL of a channel inline button
named `🛍️ خرید`. The product ID is passed to the bot.

This starter records order details but does not calculate prices or collect online payments.
Do not mark an order as paid based only on a selected payment method. Add verified payment
integration before accepting online payments.
