import os
import logging
import sqlite3
from datetime import datetime
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters,
)

TOKEN = os.environ["BOT_TOKEN"]
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}
BOT_USERNAME = os.getenv("BOT_USERNAME", "Saaren_Mezon_bot")
STORE_CHANNEL = os.getenv("STORE_CHANNEL", "@saaren_mezon_hamkari")
DB_PATH = os.getenv("DB_PATH", "orders.db")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
log = logging.getLogger(__name__)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, username TEXT, product_id TEXT,
        size TEXT, color TEXT, quantity INTEGER,
        shipping TEXT, payment TEXT, address TEXT,
        created_at TEXT, status TEXT DEFAULT 'ثبت‌شده'
    )""")
    conn.commit()
    return conn

def is_admin(user_id):
    return user_id in ADMIN_IDS

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    payload = context.args[0] if context.args else ""
    if payload.startswith("product_"):
        product_id = payload.removeprefix("product_")
        context.user_data["order"] = {"product_id": product_id}
        keyboard = [[InlineKeyboardButton(s, callback_data=f"size:{s}")]
                    for s in ["۳۶", "۳۸", "۴۰", "۴۲", "۴۴", "سایر"]]
        await update.message.reply_text(
            f"خوش آمدید به Saaren Shop 💗\nمحصول انتخابی: {product_id}\n\nسایز را انتخاب کنید:",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )
        return

    keyboard = [
        [InlineKeyboardButton("👗 فروشگاه لباس‌ها", url=f"https://t.me/{STORE_CHANNEL.lstrip('@')}")],
        [InlineKeyboardButton("🛒 سبد خرید / سفارش‌های من", callback_data="myorders")],
        [InlineKeyboardButton("📦 پیگیری سفارش", callback_data="track")],
        [InlineKeyboardButton("👤 حساب کاربری", callback_data="account"),
         InlineKeyboardButton("☎️ پشتیبانی", url="https://t.me/AlTiPs")],
    ]
    await update.message.reply_text(
        "به Saaren Shop | فروشگاه سارن خوش آمدید 💖\n"
        "برای خرید، از کانال لباس‌ها روی دکمه «خرید» بزنید.",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )

async def start_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "برای خرید از کانال لباس‌ها روی دکمه خرید بزنید.\n"
        "دستورهای مدیر: /makebutton PRODUCT_ID و /orders"
    )

async def makebutton(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("این دستور فقط برای مدیر فعال است.")
        return
    if not context.args:
        await update.message.reply_text("روش استفاده: /makebutton 101")
        return
    product_id = context.args[0]
    url = f"https://t.me/{BOT_USERNAME}?start=product_{product_id}"
    await update.message.reply_text(
        f"لینک خرید محصول {product_id}:\n{url}\n\n"
        "این لینک را به‌عنوان URL دکمه «🛍️ خرید» زیر پست همان لباس در کانال قرار دهید."
    )

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data
    order = context.user_data.get("order", {})

    if data.startswith("size:"):
        order["size"] = data.split(":", 1)[1]
        context.user_data["order"] = order
        keyboard = [[InlineKeyboardButton(c, callback_data=f"color:{c}")]
                    for c in ["مشکی", "قرمز", "آبی", "سبز", "سفید", "سایر"]]
        await q.edit_message_text("رنگ موردنظر را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(keyboard))
    elif data.startswith("color:"):
        order["color"] = data.split(":", 1)[1]
        context.user_data["order"] = order
        keyboard = [[InlineKeyboardButton(str(n), callback_data=f"qty:{n}") for n in [1, 2, 3, 4, 5]]]
        await q.edit_message_text("تعداد را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(keyboard))
    elif data.startswith("qty:"):
        order["quantity"] = int(data.split(":", 1)[1])
        context.user_data["order"] = order
        keyboard = [
            [InlineKeyboardButton("📮 پست پیشتاز", callback_data="ship:پست پیشتاز")],
            [InlineKeyboardButton("🚚 تیپاکس", callback_data="ship:تیپاکس")],
        ]
        await q.edit_message_text("روش ارسال را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(keyboard))
    elif data.startswith("ship:"):
        order["shipping"] = data.split(":", 1)[1]
        context.user_data["order"] = order
        keyboard = [
            [InlineKeyboardButton("💳 کارت‌به‌کارت", callback_data="pay:کارت‌به‌کارت")],
            [InlineKeyboardButton("🌐 پرداخت آنلاین", callback_data="pay:پرداخت آنلاین")],
            [InlineKeyboardButton("💵 پرداخت در محل", callback_data="pay:پرداخت در محل")],
        ]
        await q.edit_message_text("روش پرداخت را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(keyboard))
    elif data.startswith("pay:"):
        order["payment"] = data.split(":", 1)[1]
        context.user_data["order"] = order
        context.user_data["awaiting_address"] = True
        await q.edit_message_text("لطفاً نام و شماره تماس و نشانی کامل گیرنده را در یک پیام بفرستید.")
    elif data == "myorders":
        conn = db()
        rows = conn.execute("SELECT id, product_id, status FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 10",
                            (q.from_user.id,)).fetchall()
        conn.close()
        if not rows:
            await q.edit_message_text("هنوز سفارشی ثبت نکرده‌اید.")
        else:
            await q.edit_message_text("سفارش‌های شما:\n" + "\n".join(
                f"#{r[0]} | محصول {r[1]} | {r[2]}" for r in rows))
    elif data == "track":
        await q.edit_message_text("برای پیگیری، شماره سفارش را با دستور /track شماره_سفارش ارسال کنید.")
    elif data == "account":
        await q.edit_message_text(f"شناسه کاربری شما: {q.from_user.id}\nنام: {q.from_user.full_name}")

async def text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.user_data.get("awaiting_address"):
        return
    order = context.user_data.get("order")
    if not order:
        context.user_data["awaiting_address"] = False
        return
    order["address"] = update.message.text
    user = update.effective_user
    conn = db()
    cur = conn.execute(
        """INSERT INTO orders (user_id, username, product_id, size, color, quantity,
        shipping, payment, address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (user.id, user.username or "", order.get("product_id", ""),
         order.get("size", ""), order.get("color", ""), order.get("quantity", 1),
         order.get("shipping", ""), order.get("payment", ""), order["address"],
         datetime.now().isoformat(timespec="minutes"))
    )
    order_id = cur.lastrowid
    conn.commit()
    conn.close()
    context.user_data["awaiting_address"] = False
    context.user_data.pop("order", None)

    invoice = (
        f"🧾 سفارش جدید Saaren Shop\n"
        f"شماره سفارش: #{order_id}\n"
        f"مشتری: {user.full_name} (@{user.username or 'ندارد'})\n"
        f"شناسه مشتری: {user.id}\n"
        f"محصول: {order.get('product_id')}\n"
        f"سایز: {order.get('size')}\nرنگ: {order.get('color')}\n"
        f"تعداد: {order.get('quantity')}\n"
        f"ارسال: {order.get('shipping')}\nپرداخت: {order.get('payment')}\n"
        f"نشانی و تماس:\n{order['address']}"
    )
    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_message(chat_id=admin_id, text=invoice)
        except Exception:
            log.exception("Could not send order to admin %s", admin_id)
    await update.message.reply_text(
        f"✅ سفارش شما با شماره #{order_id} ثبت شد.\n"
        "برای پیگیری از دستور /track استفاده کنید."
    )

async def track(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("روش استفاده: /track 12")
        return
    conn = db()
    row = conn.execute("SELECT user_id, status FROM orders WHERE id=?",
                       (int(context.args[0]),)).fetchone()
    conn.close()
    if not row or (row[0] != update.effective_user.id and not is_admin(update.effective_user.id)):
        await update.message.reply_text("سفارشی پیدا نشد.")
    else:
        await update.message.reply_text(f"وضعیت سفارش: {row[1]}")

async def orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("این دستور فقط برای مدیر فعال است.")
        return
    conn = db()
    rows = conn.execute("SELECT id, product_id, username, status FROM orders ORDER BY id DESC LIMIT 20").fetchall()
    conn.close()
    await update.message.reply_text(
        "آخرین سفارش‌ها:\n" + ("\n".join(f"#{r[0]} | {r[1]} | @{r[2]} | {r[3]}" for r in rows) if rows else "هنوز سفارشی نیست.")
    )

def main():
    db().close()
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", start_help))
    app.add_handler(CommandHandler("makebutton", makebutton))
    app.add_handler(CommandHandler("track", track))
    app.add_handler(CommandHandler("orders", orders))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message))
    app.run_polling()

if __name__ == "__main__":
    main()
